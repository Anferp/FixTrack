<template>
<!--  <footer class="footer">
    <div class="container">
      <p class="copyright">© 2023 FixTrack. Todos los derechos reservados.</p>
    </div>
  </footer> -->
</template>

<style scoped>
.footer {
  background-color: white;
  padding: var(--spacing-medium) 0;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.03);
  width: 100%;
  z-index: 10;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--spacing-medium);
  text-align: center;
}

.copyright {
  color: var(--medium-gray);
  font-size: 12px;
}
</style>
